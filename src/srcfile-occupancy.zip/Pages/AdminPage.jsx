import React from 'react'

const AdminPage = () => {
  return (
    <>
    <h1>Admin Page...</h1>
    </>
  )
}

export default AdminPage