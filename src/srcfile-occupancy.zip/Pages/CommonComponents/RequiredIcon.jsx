const RequiredIcon = () => <span style={{ color: 'red' }}>*</span>;


export default RequiredIcon