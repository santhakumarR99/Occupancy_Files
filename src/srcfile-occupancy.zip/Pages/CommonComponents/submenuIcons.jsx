import React from 'react'

const SubmenuIcons = (img) => {
  return (
    <div>
<img src={img } width="10px" height="10x"/>
        
    </div>
  )
}

export default SubmenuIcons